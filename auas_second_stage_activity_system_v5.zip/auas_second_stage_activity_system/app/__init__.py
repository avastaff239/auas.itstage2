import os
from pathlib import Path
from flask import Flask
from flask_login import LoginManager
from flask_sqlalchemy import SQLAlchemy
from flask_wtf.csrf import CSRFProtect
from flask_limiter import Limiter
from flask_limiter.util import get_remote_address
from werkzeug.security import generate_password_hash

db = SQLAlchemy()
login_manager = LoginManager()
csrf = CSRFProtect()
limiter = Limiter(key_func=get_remote_address, default_limits=["200 per day", "60 per hour"])

def create_app():
    app = Flask(__name__, instance_relative_config=True)
    Path(app.instance_path).mkdir(parents=True, exist_ok=True)
    upload_dir = Path(app.static_folder) / "uploads"
    upload_dir.mkdir(parents=True, exist_ok=True)

    app.config.update(
        SECRET_KEY=os.getenv("SECRET_KEY", "dev-only-change-me"),
        SQLALCHEMY_DATABASE_URI=os.getenv(
            "DATABASE_URL",
            "sqlite:///" + str(Path(app.instance_path) / "auas.db")
        ),
        SQLALCHEMY_TRACK_MODIFICATIONS=False,
        MAX_CONTENT_LENGTH=int(os.getenv("MAX_CONTENT_LENGTH", 10 * 1024 * 1024)),
        UPLOAD_FOLDER=str(upload_dir),
        ALLOWED_EXTENSIONS={"png", "jpg", "jpeg", "webp", "pdf", "doc", "docx", "ppt", "pptx"},
        SESSION_COOKIE_HTTPONLY=True,
        SESSION_COOKIE_SAMESITE="Lax",
        SESSION_COOKIE_SECURE=os.getenv("SESSION_COOKIE_SECURE", "0") == "1",
        REMEMBER_COOKIE_HTTPONLY=True,
        REMEMBER_COOKIE_SAMESITE="Lax",
        REMEMBER_COOKIE_SECURE=os.getenv("SESSION_COOKIE_SECURE", "0") == "1",
    )

    db.init_app(app)
    login_manager.init_app(app)
    csrf.init_app(app)
    limiter.init_app(app)
    login_manager.login_view = "auth.login"
    login_manager.login_message = "تکایە سەرەتا چوونەژوورەوە بکە."

    from .models import Instructor
    from .routes.public import public_bp
    from .routes.auth import auth_bp
    from .routes.admin import admin_bp

    app.register_blueprint(public_bp)
    app.register_blueprint(auth_bp)
    app.register_blueprint(admin_bp)

    with app.app_context():
        db.create_all()
        if not Instructor.query.first():
            username = os.getenv("ADMIN_USERNAME", "instructor")
            password = os.getenv("ADMIN_PASSWORD", "change-this-password")
            db.session.add(Instructor(
                username=username,
                password_hash=generate_password_hash(password)
            ))

        # Initial weekly plan for the second-stage class.
        # Weeks run Sunday through Thursday. These records are only added
        # when the corresponding week number does not already exist, so
        # existing local data is preserved.
        from datetime import date
        from .models import Week
        initial_weeks = [
            (1, date(2026, 9, 6), date(2026, 9, 10)),
            (2, date(2026, 9, 13), date(2026, 9, 17)),
            (3, date(2026, 9, 20), date(2026, 9, 24)),
        ]
        for number, start, end in initial_weeks:
            if not Week.query.filter_by(week_number=number).first():
                db.session.add(Week(week_number=number, start_date=start, end_date=end))

        db.session.commit()

    return app
