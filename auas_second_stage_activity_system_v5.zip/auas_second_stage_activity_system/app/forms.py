from flask_wtf import FlaskForm
from wtforms import StringField, PasswordField, TextAreaField, SelectField, DateField, SubmitField
from wtforms.validators import DataRequired, Length, Optional

class LoginForm(FlaskForm):
    username = StringField("ناوی بەکارهێنەر", validators=[DataRequired(), Length(max=120)])
    password = PasswordField("وشەی نهێنی", validators=[DataRequired()])
    submit = SubmitField("چوونەژوورەوە")

class WeekForm(FlaskForm):
    week_number = StringField("ژمارەی هەفتە", validators=[DataRequired(), Length(max=10)])
    start_date = DateField("دەستپێک", validators=[DataRequired()], format="%Y-%m-%d")
    end_date = DateField("کۆتایی", validators=[DataRequired()], format="%Y-%m-%d")
    submit = SubmitField("پاشەکەوتکردن")

class SubjectForm(FlaskForm):
    name = StringField("ناوی بابەت", validators=[DataRequired(), Length(max=120)])
    submit = SubmitField("پاشەکەوتکردن")

class TaskForm(FlaskForm):
    title = StringField("ناونیشانی ئەرک", validators=[DataRequired(), Length(max=200)])
    description = TextAreaField("وەسف و تێبینی", validators=[Optional(), Length(max=5000)])
    task_type = SelectField("جۆر", choices=[
        ("Homework", "📝 هوم ورک"),
        ("Activity", "🎯 چالاکی"),
        ("Assignment", "📚 ئەساينمنت"),
        ("Reading", "📖 خوێندنەوە"),
        ("Research", "🔬 توێژینەوە"),
        ("Announcement", "📢 ڕاگەیاندن"),
    ], validators=[DataRequired()])
    task_date = DateField("بەرواری ئەرک", validators=[DataRequired()], format="%Y-%m-%d")
    due_date = DateField("کۆتا بەروار", validators=[Optional()], format="%Y-%m-%d")
    week_id = SelectField("هەفتە", coerce=int, validators=[DataRequired()])
    subject_id = SelectField("بابەت", coerce=int, validators=[DataRequired()])
    submit = SubmitField("پاشەکەوتکردن")
