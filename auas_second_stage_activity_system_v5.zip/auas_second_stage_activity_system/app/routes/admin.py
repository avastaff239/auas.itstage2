from datetime import date
from pathlib import Path
from uuid import uuid4
from flask import Blueprint, render_template, redirect, url_for, flash, request, current_app, send_from_directory
from flask_login import login_required
from werkzeug.utils import secure_filename
from .. import db
from ..models import Week, Subject, Task
from ..forms import WeekForm, SubjectForm, TaskForm

admin_bp = Blueprint("admin", __name__, url_prefix="/instructor")

def allowed(filename):
    return "." in filename and filename.rsplit(".", 1)[1].lower() in current_app.config["ALLOWED_EXTENSIONS"]

def save_upload(file):
    if not file or not file.filename:
        return None
    if not allowed(file.filename):
        raise ValueError("جۆری فایل پشتگیری ناکرێت.")
    ext = file.filename.rsplit(".", 1)[1].lower()
    name = f"{uuid4().hex}.{ext}"
    file.save(Path(current_app.config["UPLOAD_FOLDER"]) / name)
    return name

@admin_bp.route("/dashboard")
@login_required
def dashboard():
    return render_template(
        "admin/dashboard.html",
        weeks=Week.query.order_by(Week.week_number.desc()).all(),
        subjects=Subject.query.order_by(Subject.name.asc()).all(),
        task_count=Task.query.count()
    )

@admin_bp.route("/weeks/new", methods=["GET", "POST"])
@login_required
def week_new():
    form = WeekForm()
    if form.validate_on_submit():
        try:
            number = int(form.week_number.data)
            if form.start_date.data > form.end_date.data:
                raise ValueError
            week = Week(week_number=number, start_date=form.start_date.data, end_date=form.end_date.data)
            db.session.add(week)
            db.session.commit()
            flash("هەفتەکە زیادکرا.", "success")
            return redirect(url_for("admin.dashboard"))
        except Exception:
            db.session.rollback()
            flash("زانیاری هەفتەکە پشکنینەوە بکە.", "error")
    return render_template("admin/week_form.html", form=form, title="زیادکردنی هەفتە")


@admin_bp.route("/weeks/<int:week_id>/edit", methods=["GET", "POST"])
@login_required
def week_edit(week_id):
    week = Week.query.get_or_404(week_id)
    form = WeekForm(obj=week)
    if form.validate_on_submit():
        try:
            week.week_number = int(form.week_number.data)
            week.start_date = form.start_date.data
            week.end_date = form.end_date.data
            if week.start_date > week.end_date:
                raise ValueError
            db.session.commit()
            flash("هەفتەکە نوێکرایەوە.", "success")
            return redirect(url_for("admin.dashboard"))
        except Exception:
            db.session.rollback()
            flash("زانیاری هەفتەکە پشکنینەوە بکە.", "error")
    return render_template("admin/week_form.html", form=form, title="دەستکاریکردنی هەفتە")

@admin_bp.route("/weeks/<int:week_id>/delete", methods=["POST"])
@login_required
def week_delete(week_id):
    week = Week.query.get_or_404(week_id)
    db.session.delete(week)
    db.session.commit()
    flash("هەفتەکە و ئەرکەکانی سڕانەوە.", "success")
    return redirect(url_for("admin.dashboard"))

@admin_bp.route("/subjects/new", methods=["GET", "POST"])
@login_required
def subject_new():
    form = SubjectForm()
    if form.validate_on_submit():
        if Subject.query.filter_by(name=form.name.data.strip()).first():
            flash("ئەم بابەتە پێشتر هەیە.", "error")
        else:
            db.session.add(Subject(name=form.name.data.strip()))
            db.session.commit()
            flash("بابەت زیادکرا.", "success")
            return redirect(url_for("admin.dashboard"))
    return render_template("admin/subject_form.html", form=form, title="زیادکردنی بابەت")


@admin_bp.route("/subjects/<int:subject_id>/edit", methods=["GET", "POST"])
@login_required
def subject_edit(subject_id):
    subject = Subject.query.get_or_404(subject_id)
    form = SubjectForm(obj=subject)
    if form.validate_on_submit():
        name = form.name.data.strip()
        existing = Subject.query.filter(Subject.name == name, Subject.id != subject.id).first()
        if existing:
            flash("ئەم بابەتە پێشتر هەیە.", "error")
        else:
            subject.name = name
            db.session.commit()
            flash("بابەتەکە نوێکرایەوە.", "success")
            return redirect(url_for("admin.dashboard"))
    return render_template("admin/subject_form.html", form=form, title="دەستکاریکردنی بابەت")

@admin_bp.route("/subjects/<int:subject_id>/delete", methods=["POST"])
@login_required
def subject_delete(subject_id):
    subject = Subject.query.get_or_404(subject_id)
    if subject.tasks:
        flash("ناتوانرێت ئەم بابەتە بسڕدرێتەوە چونکە ئەرکی پەیوەست پێیەوە هەیە.", "error")
        return redirect(url_for("admin.dashboard"))
    db.session.delete(subject)
    db.session.commit()
    flash("بابەتەکە سڕایەوە.", "success")
    return redirect(url_for("admin.dashboard"))

@admin_bp.route("/tasks/new", methods=["GET", "POST"])
@login_required
def task_new():
    form = TaskForm()
    form.week_id.choices = [(w.id, f"هەفتەی {w.week_number} — {w.start_date} تا {w.end_date}") for w in Week.query.order_by(Week.week_number.asc()).all()]
    form.subject_id.choices = [(s.id, s.name) for s in Subject.query.order_by(Subject.name.asc()).all()]
    if form.validate_on_submit():
        task = Task(
            title=form.title.data,
            description=form.description.data,
            task_type=form.task_type.data,
            task_date=form.task_date.data,
            due_date=form.due_date.data,
            week_id=form.week_id.data,
            subject_id=form.subject_id.data,
        )
        try:
            task.image_filename = save_upload(request.files.get("image"))
            task.file_filename = save_upload(request.files.get("file"))
            db.session.add(task)
            db.session.commit()
            flash("ئەرکەکە زیادکرا.", "success")
            return redirect(url_for("admin.dashboard"))
        except ValueError as e:
            db.session.rollback()
            flash(str(e), "error")
        except Exception:
            db.session.rollback()
            flash("هەڵەیەک ڕوویدا لە پاشەکەوتکردنی فایل.", "error")
    return render_template("admin/task_form.html", form=form, title="زیادکردنی ئەرک")

@admin_bp.route("/tasks/<int:task_id>/edit", methods=["GET", "POST"])
@login_required
def task_edit(task_id):
    task = Task.query.get_or_404(task_id)
    form = TaskForm(obj=task)
    form.week_id.choices = [(w.id, f"هەفتەی {w.week_number} — {w.start_date} تا {w.end_date}") for w in Week.query.order_by(Week.week_number.asc()).all()]
    form.subject_id.choices = [(s.id, s.name) for s in Subject.query.order_by(Subject.name.asc()).all()]
    if form.validate_on_submit():
        task.title = form.title.data
        task.description = form.description.data
        task.task_type = form.task_type.data
        task.task_date = form.task_date.data
        task.due_date = form.due_date.data
        task.week_id = form.week_id.data
        task.subject_id = form.subject_id.data
        try:
            new_image = save_upload(request.files.get("image"))
            new_file = save_upload(request.files.get("file"))
            if new_image:
                task.image_filename = new_image
            if new_file:
                task.file_filename = new_file
            db.session.commit()
            flash("ئەرکەکە نوێکرایەوە.", "success")
            return redirect(url_for("admin.dashboard"))
        except ValueError as e:
            db.session.rollback()
            flash(str(e), "error")
        except Exception:
            db.session.rollback()
            flash("هەڵەیەک ڕوویدا.", "error")
    return render_template("admin/task_form.html", form=form, title="دەستکاریکردنی ئەرک")

@admin_bp.route("/tasks/<int:task_id>/delete", methods=["POST"])
@login_required
def task_delete(task_id):
    task = Task.query.get_or_404(task_id)
    db.session.delete(task)
    db.session.commit()
    flash("ئەرکەکە سڕایەوە.", "success")
    return redirect(url_for("admin.dashboard"))

@admin_bp.route("/uploads/<path:filename>")
@login_required
def protected_upload(filename):
    return send_from_directory(current_app.config["UPLOAD_FOLDER"], filename)
