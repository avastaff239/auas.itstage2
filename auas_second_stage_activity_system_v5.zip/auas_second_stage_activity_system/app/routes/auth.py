from flask import Blueprint, render_template, redirect, url_for, flash
from flask_login import login_user, logout_user
from werkzeug.security import check_password_hash
from .. import db, login_manager, limiter
from ..models import Instructor
from ..forms import LoginForm

auth_bp = Blueprint("auth", __name__, url_prefix="/instructor")

@login_manager.user_loader
def load_user(user_id):
    return Instructor.query.get(int(user_id))

@auth_bp.route("/login", methods=["GET", "POST"])
@limiter.limit("5 per minute")
def login():
    form = LoginForm()
    if form.validate_on_submit():
        user = Instructor.query.filter_by(username=form.username.data.strip()).first()
        if user and check_password_hash(user.password_hash, form.password.data):
            login_user(user, remember=False)
            return redirect(url_for("admin.dashboard"))
        flash("ناوی بەکارهێنەر یان وشەی نهێنی هەڵەیە.", "error")
    return render_template("auth/login.html", form=form)

@auth_bp.route("/logout", methods=["POST"])
def logout():
    logout_user()
    return redirect(url_for("public.dashboard"))
