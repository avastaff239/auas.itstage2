from datetime import date
from flask import Blueprint, render_template, abort
from ..models import Week, Task

public_bp = Blueprint("public", __name__)

@public_bp.route("/")
def dashboard():
    weeks = Week.query.order_by(Week.week_number.desc()).all()
    current = None
    today = date.today()
    for w in weeks:
        if w.start_date <= today <= w.end_date:
            current = w
            break
    if current is None and weeks:
        current = weeks[0]
    tasks = sorted(current.tasks, key=lambda t: (t.task_date, t.id)) if current else []
    return render_template("public/dashboard.html", weeks=weeks, current=current, tasks=tasks, today=today)

@public_bp.route("/week/<int:week_id>")
def week_view(week_id):
    week = Week.query.get_or_404(week_id)
    tasks = sorted(week.tasks, key=lambda t: (t.task_date, t.id))
    return render_template("public/week.html", week=week, tasks=tasks)
